# 枫叶 VPN Android 源码包（第一版模板）

App 名称：枫叶  
图标：枫叶 🍁  
风格：科技蓝光风  
启动文案：安全放心  

> 说明：这是一个可用于 GitHub 云端打包的 Android 源码模板，包含界面、内置节点配置、GitHub Actions 打包脚本。  
> 要实现真正一键连接，需要继续集成 Xray/v2ray 内核或基于 v2rayNG 做定制版。本模板用于第一步搭建品牌 App 工程。

## 内置节点

```text
vmess://ewogICJ2IjogIjIiLAogICJwcyI6ICIiLAogICJhZGQiOiAiNDUuNzYuMjIwLjE1NSIsCiAgInBvcnQiOiA0OTc2OSwKICAiaWQiOiAiNmMxNzRiOWUtNTNiNi00OGI3LTg0OTktMGYwYzE0MDg3MjY2IiwKICAiYWlkIjogMCwKICAibmV0IjogInRjcCIsCiAgInR5cGUiOiAibm9uZSIsCiAgImhvc3QiOiAiIiwKICAicGF0aCI6ICIiLAogICJ0bHMiOiAibm9uZSIKfQ==
```

## 手机 GitHub 打包

1. 新建 GitHub 仓库：`fengye-vpn`
2. 上传本源码包全部文件
3. 打开 Actions
4. 运行 `Build Android APK`
5. 在 Artifacts 下载 APK

## 后续真正可连接版

推荐 fork `2dust/v2rayNG`，再替换：
- App 名称
- 图标
- 默认订阅/节点
- 首页 UI

公开发布时请遵守相关开源协议与当地法律法规。
