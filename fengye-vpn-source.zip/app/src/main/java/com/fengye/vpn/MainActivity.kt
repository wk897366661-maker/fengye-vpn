package com.fengye.vpn

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val builtInNode = "vmess://ewogICJ2IjogIjIiLAogICJwcyI6ICIiLAogICJhZGQiOiAiNDUuNzYuMjIwLjE1NSIsCiAgInBvcnQiOiA0OTc2OSwKICAiaWQiOiAiNmMxNzRiOWUtNTNiNi00OGI3LTg0OTktMGYwYzE0MDg3MjY2IiwKICAiYWlkIjogMCwKICAibmV0IjogInRjcCIsCiAgInR5cGUiOiAibm9uZSIsCiAgImhvc3QiOiAiIiwKICAicGF0aCI6ICIiLAogICJ0bHMiOiAibm9uZSIKfQ=="

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(0xFF061A3A.toInt())
        }

        val title = TextView(this).apply {
            text = "枫叶 VPN"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
        }

        val sub = TextView(this).apply {
            text = "安全放心"
            textSize = 20f
            setTextColor(0xFF78B7FF.toInt())
            setPadding(0, 16, 0, 48)
        }

        val node = TextView(this).apply {
            text = "日本东京高速节点"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 24)
        }

        val status = TextView(this).apply {
            text = "状态：未连接"
            textSize = 18f
            setTextColor(0xFFB8D7FF.toInt())
            setPadding(0, 0, 0, 48)
        }

        val copyBtn = Button(this).apply {
            text = "复制节点链接"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("fengye-node", builtInNode))
                Toast.makeText(this@MainActivity, "已复制，去 V2Box 从剪贴板导入", Toast.LENGTH_LONG).show()
            }
        }

        val note = TextView(this).apply {
            text = "第一版模板：用于品牌展示与复制内置节点。真正一键连接版需继续集成 Xray 内核。"
            textSize = 14f
            setTextColor(0xFF9ABCE8.toInt())
            setPadding(0, 36, 0, 0)
        }

        root.addView(title)
        root.addView(sub)
        root.addView(node)
        root.addView(status)
        root.addView(copyBtn)
        root.addView(note)
        setContentView(root)
    }
}
